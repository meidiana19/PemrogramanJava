# JAVA_RMI-Calculator_ClientServer
Simple Cliente and Server RMI

# Screenshots
![Alt text](/capturas/cap1.png)
![Alt text](/capturas/cap2.png)
![Alt text](/capturas/cap3.png)
![Alt text](/capturas/cap4.png)